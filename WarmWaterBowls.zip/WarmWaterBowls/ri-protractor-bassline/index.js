exports.printMsg = function() {
    console.log("This is a message from ri-protractor-bassline package");
}