/**
 * Created by panhuisi on 10-10-2017.
 */

var pageElements = require(config.pageElementsPath);
var helper = require('./helperFunctions');
var request = require('superagent');
var chai = require("chai");
var chaiAsPromised = require("chai-as-promised");
chai.use(chaiAsPromised);
var expect = chai.expect;
var mkdirp = require('mkdirp');

var apiActions = function () {
    'use strict';


    /**
     * creates a promise for opening a browser session and logs in using sam stub using a post-request, then uses
     * authenticated session to send a get-request with the params headerKey and headerValue as a http header. Stores
     * the response in browser.currentTestData['apiRes'] and the body in browser.currentTestData['apiResBody'] until
     * test cycle is done
     * @function apiGetWithHeader
     * @param headerKey http header key that will be included in the get-request
     * @param headerValue http header key value that will be included in the get-request
     * @param url url to send the get-request to
     * @param page page object on which the page-objects selector can be resolved.
     */
    var apiGetWithHeader = function (headerKey, headerValue, url, page) {
        browser.currentTestData['apiRes'] = null;
        url = pageElements().selectPage[page].selectors[url];
        return new Promise(function (resolve, reject) {
            var defaultUser = pageElements().selectPage['sam'].selectors['defaultUser'];
            var loginUrl = browser.baseUrl + '/sam/handleLogin.htm';
            const agent = request.agent();
            console.log(loginUrl);
            console.log(defaultUser);
            agent.post(loginUrl)
                .query({'type': 'customer'})
                .query({'securityLevel': '3'})
                .query({'customerKey': defaultUser})
                .query({'siteContextPath': '/klanten'})
                .query({'url': '/saldoverloop.html'})
                .end(function (err, response) {
                    if (err) {
                        console.log('something went wrong logging in \n' + 'error at api Get ' + err.status);
                        reject(err);
                    } else if (response) {
                        console.log('Got response at login ok');
                        console.log(url);
                        agent.get(url)
                            .set(String(headerKey), String(headerValue))
                            .type('json')
                            .then(function (response, err) {
                                if (err) {
                                    console.log('something went wrong posting userpreferences \n' + 'error: ' + err);
                                    reject(err)
                                } else if (response) {
                                    console.log('Got response posting userpreferences:OK');
                                    browser.currentTestData['apiRes'] = response;
                                    browser.currentTestData['apiResBody'] = response.body;
                                    resolve(response)
                                }
                            })
                    }
                })

        })
    };


    /**
     * Do not use this function, it does not work yet
     * @author StofkoperC
     * @function apiGetAcc
     * @param apiUrl
     */
    var apiGetAcc = function (apiUrl) {
        browser.currentTestData['apiRes'] = null;
        function printCookies(level,callback) {
            browser.manage().getCookies().then(function (value) {
                console.log('mien cookie br info is nu:  ==> ',level,  value)
            }).then(callback)
        }
        return new Promise(function (resolve, reject) {
            var defaultUser = pageElements().selectPage['loginAcpt'].selectors['defaultUser'];
            var getContextUrl = browser.baseUrl + 'klanten/setdebitcardforauth.do?AuthId='+defaultUser[0]+'&AuthBpasNr='+defaultUser[1];
            var getGencodeUrl = browser.baseUrl + 'gencode/gencode-auth/rs/'+defaultUser[0]+'/'+defaultUser[1];
            const agent = request.agent();
            console.log('Step 1' , getContextUrl);
            // Step 1 : get the context (color Code)
            agent.get(getContextUrl)
                .end(function (err, response) {
                    if (err) {
                        console.log('error at api Get ', err.status);
                        reject(err);
                    } else if (response) {
                        console.log('Got response at getting color code ', response.body )
                        console.log('Step 2' , getGencodeUrl);
                        console.log(response.headers)
                        // step 2 get the Gencode
                        // browser.manage().getCookies().then(function (cookies) {
                        //
                        // })
                        agent.get(getGencodeUrl).withCredentials().end(function (err, response) {
                            if (err) {
                                console.log('error at api Get ', err.status);
                                reject(err);
                            } else if (response) {
                                console.log('Got response at getting gencode ', response.body)
                                console.log(response.headers)


                                console.log('Step 4' , apiUrl);
                                // step 4 do the desired api get call
                                agent.get(apiUrl).type('json').then(function (response, err) {

                                    if (err) {
                                        console.log('something went getting api response from : '+ apiUrl);
                                        console.log('error: ', err);
                                        reject(err)
                                    } else if (response) {
                                        console.log('Got response from url :OK ==> '+apiUrl)
                                        browser.currentTestData['apiRes'] = response;
                                        resolve(response)
                                    }
                                })
                            }
                        })

                    }
                })

        })
    };

    /**
     * creates a promise for opening a browser session and logs in using sam stub using a post-request, then uses
     * authenticated session to send an authenticated post-request with param jsondata to param url. Stores
     * the response in browser.apiRes until test cycle is done
     * @function apiPost
     * @param url url where the JSON data of param jsondata will be sent to
     * @param jsonData JSON data to be sent to param URL
     */
    var apiPost = function (url, jsonData) {
        browser.apiRes = null;
        return new Promise(function (resolve, reject) {
            var defaultUser = pageElements().selectPage['sam'].selectors['defaultUser'];
            var loginUrl = browser.baseUrl + 'sam/handleLogin.htm';
            const agent = request.agent();
            console.log(loginUrl);
            console.log(url);
            agent.post(loginUrl).buffer().type('json').query({'type': 'customer'}).query({'securityLevel': '3'}).query({'customerKey': defaultUser}).query({'siteContextPath': '/klanten'}).query({'url': '/'})
                .end(function (err, response) {

                    if (err) {
                        console.log('something went wrong logging in');
                        console.log('error: ', err);
                        reject(err);
                    } else if (response) {
                        console.log('Got response at login ok');
                        agent.post(url).type('json').send(jsonData).buffer().end(function (err, response) {

                            if (err) {
                                console.log('something went wrong posting userpreferences');
                                console.log('error: ', err);
                                reject(err)
                            } else if (response) {
                                console.log('Got response posting userpreferences:OK');
                                browser.apiRes = response;
                                resolve(response)
                            }
                        })
                    }
                })
        })
    };

    /**
     * @author StokoperC
     * @function apiGet
     * @param url
     */
    var apiGet = function (url) {
        browser.currentTestData['apiRes'] = null;
        return new Promise(function (resolve, reject) {
            var defaultUser = pageElements().selectPage['sam'].selectors['defaultUser'];
            var loginUrl = browser.baseUrl + 'sam/handleLogin.htm';
            const agent = request.agent();
            console.log(loginUrl);
            agent.post(loginUrl).query({'type': 'customer'}).query({'securityLevel': '3'}).query({'customerKey': defaultUser}).query({'siteContextPath': '/klanten'}).query({'url': '/'})
                .end(function (err, response) {
                    if (err) {
                        console.log('something went wrong logging in');
                        console.log('error at api Get ', err.status);
                        reject(err);
                    } else if (response) {
                        console.log('Got response at login ok')
                        agent.get(url).type('json').then(function (response, err) {

                            if (err) {
                                console.log('something went wrong posting userpreferences');
                                console.log('error: ', err);
                                reject(err)
                            } else if (response) {
                                console.log('Got response posting userpreferences:OK')
                                browser.currentTestData['apiRes'] = response;
                                browser.currentTestData['apiResBody'] = response.body;
                                resolve(response)
                            }
                        })
                    }
                })

        })
    };

    /**
     * creates a promise to send a get-request to url of param url. Response is parsed to JSON and stored in
     * browser.currentTestData.frontEndJsonResponse for the duration of the test cycle.
     * @function extractStubData
     * @param url the url selector on the page-object of param page
     * @param page page object on which the page-objects selector can be resolved.
     */
    var extractStubData = function (url, page) {
        url = pageElements().selectPage[page].selectors[url];
        return new Promise(function (resolve, reject) {
            request.get(url).end(function (err, response) {
                if (err) {
                    console.log('An error has been thrown:' + ' - error code: ', err.code + ' - error status: ', err.status);
                    reject(err);
                } else if (response) {
                    browser.currentTestData.frontEndJsonResponse = JSON.parse(response.text);
                    resolve(browser.currentTestData.frontEndJsonResponse)
                } else {
                    console.log('An uncaught error occurred, please check code!');
                    reject(err);
                }
            });
        })
    };


    /**
     * creates a promise to use helper().apiGetWithHeader to send get-request to url of param url using the params
     * headerKey and headerValue. Response is parsed to JSON and stored in
     * browser.currentTestData.parsedPifProxyResponse for the duration of the test cycle.
     * @function extractDataFromEndpoint
     * @param url page-objects selector for the url where Data is extracted
     * @param headerKey page-objects selector for the header key that is used to call the resolved URL
     * @param headerValue page-objects selector for the header value that is belongs to param headerKey
     * @param page page object on which the page-objects selector can be resolved.
     */
    var extractDataFromEndpoint = function (url, page, headerKey, headerValue) {
        return new Promise(function (resolve) {
            // helper().apiGetWithHeader(headerKey, headerValue, url, page)
            apiGetWithHeader(headerKey, headerValue, url, page)
                .then(function (response) {
                    browser.currentTestData.parsedPifProxyResponse = JSON.parse(response.text);
                    resolve(browser.currentTestData.parsedPifProxyResponse)
                })
        })
    };


    /**
     * Checks the reponse body for a response that has been stored in currentTestData.apiRes.
     * @param expectedType String "code" or "substring" (not implemented yet)
     * @param expectedValue
     */
    var checkApiResponse = function (expectedType, expectedValue) {
        switch (expectedType) {
            case 'code': {
                return expect('' + browser.currentTestData['apiRes'].statusCode, 'Expected responsecode was ' + expectedValue + 'but was: ' + browser.currentTestData['apiRes'].statusCode).to.equal(expectedValue);
                break;
            }
            case 'substring': {
                console.log('sub');
                break;
            }
            default: {
                console.log('This test does nothing, please review')
            }
        }
    };

    /**
     * Checks the reponse body for a response that has been stored in currentTestData.apiRes. Uses jsonPath query
     * @param queryString String with jsonPath, specified in Scenario
     * @param beOrContain String "be" or "contain" (specified in Scenario
     * @param expectedValue the expected result (String)
     */
    var checkApiResponseQuery = function (queryString, beOrContain, expectedValue) {
        console.log('apiRes =============>> ', browser.currentTestData.apiRes.body)
        var queryResult = jp.query(browser.currentTestData['apiRes'].body, queryString);
        if (beOrContain === 'be') {
            return expect('' + queryResult, 'Expected the query "' + queryString + '" on the api result to yield the result ' + expectedValue + ' but was: ' + queryResult)
                .to.be.equal(expectedValue);
        }
        else if (beOrContain === 'contain') {
            return expect('' + queryResult, 'Expected the query "' + queryString + '" on the api result to yield a result containing ' + expectedValue + ' but was: ' + queryResult)
                .to.include(expectedValue);
        }
        else if (beOrContain === 'have length') {
            return expect(Object.keys(queryResult).length, 'Expected the query "' + queryString + '" on the api result to yield ' + expectedValue + ' results ' + JSON.stringify(queryResult) + ' were found')
                .to.be.equal(Number(expectedValue));
        }
    };

    /**
     * Performs an api get call. Uses the helper apiGet method, first logging in to get the cookies and then performing the actual caal.
     * The response will be stored in browser.currentTestData.apiRes. Checks whether the api call returns a result.
     * It has a possibility for Acc but that does not work yet!
     * @param url String with a reference to a url specified in "general" page-object
     */
    var getApiAsAClient = function (url) {
        var apiUrl = pageElements().selectPage['general'].selectors[url];
        if (browser.baseUrl.indexOf('acpt') === -1) {
            return expect(helper().apiGet(apiUrl), 'something went wrong with the get call to rest api: ').to.eventually.not.equal(null);
        } else {
            return expect(helper().apiGetAcc(apiUrl), 'something went wrong with the get call to rest api: ').to.eventually.not.equal(null);

        }
    };

    /**
     *
     * @param url Is the url of the rest endpoint
     * @param key Is the key that is queried in the response
     * @param expectedValue Is the value that is being verified
     */
    var getRestAndQuery = function (url, key, expectedValue) {
        return new Promise(function (resolve, reject) {
            request.get(url).end(function (err, response) {
                if (err) {
                    console.log('An error has been thrown:');
                    console.log('- error code: ', err.code);
                    console.log('- error status: ', err.status);
                    reject(err)
                } else if (response) {
                    resolve(response)
                }
                expect(response.body[key], 'Actual Result did not match the expected value').to.equal(expectedValue);
            })
        })
    };

    /**
     *
     * @param url Is the url of the rest endpoint
     * @param element Is element to query for
     * @param expectedResult
     */
    var postSoapAndQuery = function (url, element, expectedResult) {
        return new Promise(function (resolve, reject) {
            var soapBody = pageElements().selectPage['general'].selectors['soapBodyGetQuote'];
            var fetchedValue = '<default>';
            request.post(url).type('xml').send(soapBody).end(function (err, response) {
                if (err) {
                    console.log('An error has been thrown:');
                    console.log('- error code: ', err.code);
                    console.log('- error status: ', err.status);
                    reject(err);
                } else if (response) {
                    resolve(response)
                }
                parseString(response.text, function (err, soapReplyToJson) {
                    fetchedValue = jp.query(soapReplyToJson, element);
                });
                var actualResult = JSON.stringify(fetchedValue);
                expect(actualResult, 'Actual result did not contain the expected value').to.include(expectedResult);
            })
        })
    };

    /**
     * Performs an api post call. Uses the helper apiPost method, first logging in to get the cookies and then performing the actual call.
     * @param json String referecing a json string specified in "general" page-object
     * @param url String referencing a url specified in "general" page-object
     */
    var postToApiAsAClient = function (json, url) {
        var jsonString = pageElements().selectPage['general'].selectors[json];
        var apiUrl = pageElements().selectPage['general'].selectors[url];
        return expect(helper().apiPost(apiUrl, jsonString), 'something went wrong with the post call to rest api').to.eventually.not.equal(null);
    };

    return {
        apiGetWithHeader: apiGetWithHeader,
        apiGetAcc: apiGetAcc,
        apiPost: apiPost,
        apiGet: apiGet,
        extractDataFromEndpoint: extractDataFromEndpoint,
        extractStubData: extractStubData,
        checkApiResponse: checkApiResponse,
        checkApiResponseQuery: checkApiResponseQuery,
        getApiAsAClient: getApiAsAClient,
        getRestAndQuery: getRestAndQuery,
        postToApiAsAClient: postToApiAsAClient,
        postSoapAndQuery: postSoapAndQuery
    };
};
module.exports = apiActions;