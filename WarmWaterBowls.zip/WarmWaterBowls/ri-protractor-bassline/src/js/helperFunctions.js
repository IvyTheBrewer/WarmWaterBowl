var pageElements = require(config.pageElementsPath);
var request = require('superagent');

var helper = function () {
    'use strict';

    var apiPost = function (url, jsonData) {
        browser.currentTestData['apiRes'] = null;
        return new Promise(function (resolve, reject) {
            var defaultUser = pageElements().selectPage['sam'].selectors['defaultUser'];
            var loginUrl = browser.baseUrl + 'sam/handleLogin.htm';
            const agent = request.agent();
            console.log(loginUrl);
            console.log(url);
            agent.post(loginUrl).buffer().type('json').query({'type': 'customer'}).query({'securityLevel': '3'}).query({'customerKey': defaultUser}).query({'siteContextPath': '/klanten'}).query({'url': '/'})
                .end(function (err, response) {

                    if (err) {
                        console.log('something went wrong logging in');
                        console.log('errorRR: ', err);
                        reject(err);
                    } else if (response) {
                        console.log('Got response at login ok')
                        agent.post(url).type('json').send(jsonData).buffer().end(function (err, response) {

                            if (err) {
                                console.log('something went wrong posting userpreferences');
                                console.log('error: ', err);
                                reject(err)
                            } else if (response) {
                                console.log('Got response posting userpreferences:OK')
                                browser.currentTestData['apiRes'] = response;
                                browser.currentTestData['apiResBody'] = response.body;
                                resolve(response)
                            }
                        })
                    }
                })
        })
    };






    /**
     * Clicks on an element. Alternative to elem.click() in case that does not work (e.g. scrolling issues)
     * @function clickPureJS
     * @param elem Element to click
     */
    var clickPureJS = function (elem) {
        browser.controlFlow().execute(function () {
            browser.executeScript("arguments[0].click();", elem);
        })
    };



    /**
     * Takes a promise of an array of web elements and filters these by function
     * @param getInputArray is a promise of an array of (web) elements
     * @param filterBy a function evaluating to a boolean. If true that input element (elem) is added to the results array
     */
    var filterArrayByFunction = function (getInputArray, filterBy) {
        return new Promise(function (resolve) {
                var promises = [];
                getInputArray().then(function (elementArray) {
                    var i = 0;
                    elementArray.forEach(function (elem) {
                        if(filterBy){
                            promises.push(filterBy(elem))
                        }else{
                            promises.push(elem)
                        }
                        i++;
                    })
                }).then(function () {
                    Promise.all(promises).then(function (filteredArray) {
                        resolve(filteredArray)
                    })
                })
            }
        )
    }

    /**
     * Takes an array of Strings referencing css selectors and returns an array of web elements
     * @param data array of Strings specified in the pipe table in scenario
     * @param page String referencing a page object
     * @param superElem String referencing a css selector in page object
     * @returns {Array} of web elements
     */
    var getDomArray = function (data, page, superElem) {
        var domArray = [];
        for (var i = 0; i < data.length; i++) {
            domArray[i] = getElement(page, data[i], superElem);
        }
        return domArray;
    };

    /**
     * gets an element based on page and selector as per scenario
     * @param page String referencing a page object
     * @param elem String referencing a css selector in page object
     * @param superElem String referencing a css selector in page object. Optional.
     * @returns web element
     */
    var getElement = function (page, elem, superElem) {
        if (superElem) {
            return element(by.css(pageElements().selectPage[page].selectors[superElem])).element(by.css(pageElements().selectPage[page].selectors[elem]));
        } else {
            return element(by.css(pageElements().selectPage[page].selectors[elem]));
        }
    };



    var getElementCenterPosition = function (elem) {
        return new Promise(function (resolve) {
            elem.getSize().then(function (value) {
                var centerPosition = value.width / 2;
                resolve(centerPosition)
            })
        })
    };

    var getElements = function (elem) {
        return element.all(by.css(elem));
    };


    /**
     * Takes promise of an input array of elements from web page, filters it by a filter-function, and returns the filtered array of results.
     * Step 1: get an array of web elements
     * Step 2: perform a filter and return the filtered array (e.g. an array of all the id's of the elements)
     * Step 3: perform a check and return an array of errors/results (e.g. add element to results array if id does not contain "foo" )
     * @returns an array of results
     * @param getThisArray function that return a promise of an initial array
     * @param filterArrayBy function that returns a promise of a filtered array out of initial array, "undefined" can be passed to bypass.
     * @param checker function that returns a boolean (if true, element is added to resultArray), and a (error)message
     * @param expectedResult argument to be used in checker e.g. 'expectedString' or true
     */
    function getFilteredAndCheckedArray (getInputArray, filterArrayBy, checker, expectedResult) {
        return new Promise(function (resolve) {
            var res = [];
            filterArrayByFunction(getInputArray, filterArrayBy).then(function (arr) {
                //console.log(arr)
                arr.forEach(function (elm) {
                    if (checker(elm, expectedResult).result) {
                        res.push(checker(elm, expectedResult).message)
                    }
                });
                resolve(res)
            })
        })

    }



    return {
        apiPost: apiPost,
        clickPureJS: clickPureJS,
        filterArrayByFunction:filterArrayByFunction,
        getDomArray: getDomArray,
        getElement: getElement,
        getElementCenterPosition: getElementCenterPosition,
        getElements: getElements,
        getFilteredAndCheckedArray:getFilteredAndCheckedArray
    };
};
module.exports = helper;

