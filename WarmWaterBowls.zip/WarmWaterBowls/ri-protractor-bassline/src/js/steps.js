var actions = require('./actions');
var apiActions = require('./apiActions');
var sideActions = require('./sideActions');


/*jshint validthis:true */
function steps() {
    'use strict';

    this.Given(/^I have a clear browser$/, actions().clearBrowser);

    this.Given(/^I am on the( secure| anonymous)? (url|site|page) "([^"]*)?"$/, actions().openWebsite);

    this.Given(/^I am logged in as a client()*()*$/, actions().loginAsClient);

    this.Given(/^I am logged in as a client "([^"]*)()*"$/, actions().loginAsClient);

    this.Then(/^I expect the result of the api call to have (code|substring) "([^"]*)"$/, apiActions().checkApiResponse);

    this.Then(/^I expect the result of query "([^"]*)" on the response to (be|contain|have length) "([^"]*)"$/, apiActions().checkApiResponseQuery);

    this.When(/^I logout$/, actions().logout);

    this.Given(/^the checkbox "([^"]*)" in the element "([^"]*)" is (un)*checked on page "([^"]*)"$/, actions().checkBoxIschecked);

    this.Then(/^the checkboxes in the element "([^"]*)" on page "([^"]*)" are (un)*checked$/, actions().checkboxesWithinElementAreChecked);

    this.Given(/^the element "([^"]*)" has property "([^"]*)" (with|containing)( no)* value "([^"]*)" on the page "([^"]*)"$/, actions().elementHasPropertyWithValueX);

    this.Then(/^the element "([^"]*)" has an element "([^"]*)" with property "([^"]*)" with value "([^"]*)" on the page "([^"]*)"$/, actions().elementHasChildElementWithPropertyXAndValueY);

    this.Then(/^the element "([^"]*)" (contains|does not contain) an element "([^"]*)" on page "([^"]*)"$/, actions().elementContainsChildElement);

    this.Given(/^the element "([^"]*)" (contains|does not contain) elements on page "([^"]*)"$/, actions().elementContainsMultipleChildElements);

    this.Given(/^the element "([^"]*)" (does not contain|contains) text "([^"]*)" on the page "([^"]*)"$/, actions().elementHasText);

    this.Given(/^the element "([^"]*)" is( not)* displayed on the page "([^"]*)"$/, actions().elementIsDisplayed);

    this.Then(/^the element "([^"]*)" is( not)* displayed on the page "([^"]*)" inside the element "([^"]*)"$/, actions().elementIsDisplayedInsideElement);

    this.Given(/^the elements are( not)* displayed on the page "([^"]*)" inside the element "([^"]*)"$/, actions().multipleElementsDisplayedInsideElement);

    this.Then(/^I send a Get-message to: "([^"]*)" and expect the key: "([^"]*)" to be value: "([^\"]*)"$/, apiActions().getRestAndQuery);

    this.Then(/^I send a Soap-message to: "([^"]*)" and expect the element: "([^"]*)" to contain the value "([^"]*)"$/, apiActions().postSoapAndQuery);

    this.When(/^I (un)*check the checkbox "([^"]*)" in the element "([^"]*)" on page "([^"]*)"$/, actions().checkCheckboxWithinElement);

    this.When(/^I (un)*check the checkboxes in the element "([^"]*)" on page "([^"]*)"$/, actions().checkMultipleCheckboxesWithinElement);

    this.Given(/^I click on element "([^"]*)" in the element "([^"]*)" on page "([^"]*)"$/, actions().clickOnElementWithinElement);

    this.When(/^I delete my cookies$/, actions().deleteCookies);

    this.When(/^I do a get\-call to "([^"]*)"$/, apiActions().getApiAsAClient);

    this.When(/^I post "([^"]*)" to "([^"]*)"$/, apiActions().postToApiAsAClient);

    this.When(/^I retrieve the child elements that exist in parent element "([^"]*)" on the page "([^"]*)"$/, actions().getElementChilds);

    this.Then(/^I verify that the "([^"]*)" of the element "([^"]*)" on the page "([^"]*)" is "([^"]*)"$/, actions().verifyCss);

    this.When(/^I send an authenticated api get call to "([^"]*)"$/, apiActions().getApiAsAClient);

    this.Given(/^I set the cookie accept to level "([^"]*)"$/, actions().acceptCookieLevel);

    this.When(/^I set the value of cookie "([^"]*)" to "([^"]*)"$/, actions().setCookieValue);

    this.Then(/^the pagesource should contain "([^"]*)()*"$/, actions().pageSourceContains);

    this.Then(/^the pagesource should contain "([^"]*)" on page "([^"]*)"$/, actions().pageSourceContains);

    this.Then(/^I pause for "([^"]*)" ms$/, actions().pause);

    this.Then(/^the value of cookie "([^"]*)" is "([^"]*)"$/, actions().cookieValueIs);

    this.Then(/^all subs of "([^"]*)" are displayed$/, actions().checkArrayPoc);

    this.Then(/^I log "([^"]*)"$/, sideActions().logger);

    this.Then(/^I take the attribute "([^"]*)" of the element "([^"]*)" from "([^"]*)" and extract it's values, starting from string position "([^"]*)", using "([^"]*)" as a seperator$/, actions().getStringAndExtractValues);

    this.Given(/^I fetch PIF Proxy stub data from url "([^"]*)" from page "([^"]*)"$/, apiActions().extractStubData);

    this.Given(/^I fetch PIF Proxy stub data from url "([^"]*)" from page "([^"]*)" using header key "([^"]*)" with header value "([^"]*)"$/, apiActions().extractDataFromEndpoint);


    this.Before(function (scenario, callback) {
        browser.currentTestData = {};
        browser.sleep(1).then(callback);

        /* Example usage of the currentTestData object to pass data between steps:

         browser.currentTestData['one'] = 1;
         browser.currentTestData['two'] = [2, 3, 4, 5];
         browser.currentTestData['three'] = 'hallo';
         browser.currentTestData['four'] = {'hallo': 'leuk'};
         console.log(browser.currentTestData)
         console.log(browser.currentTestData.two);
         console.log(browser.currentTestData.two[1])
         console.log(browser.currentTestData['three'])
         console.log(browser.currentTestData.four['hallo'])
         browser.sleep(1).then(callback)*/

    });

    this.After(function (scenario, callback) {
        actions().clearBrowser();
        browser.currentTestData = null;
        browser.sleep(1).then(callback);

    })
}

module.exports = steps;
