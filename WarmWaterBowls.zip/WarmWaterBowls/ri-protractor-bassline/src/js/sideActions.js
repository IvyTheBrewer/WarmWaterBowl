/* global browser, driver, by */

var pageElements = require(config.pageElementsPath);
var helper = require('./helperFunctions');

var sideActions = function () {
        'use strict';

        /**
         * @function logger
         * @param text: is the text that is passed to this function for it to write to the console log
         */
        var logger = function (text) {
            console.log('**************** logger speaks ********************* ');
            console.log(text);
            console.log('**************** logger speaks ********************* ')
        };

        return {
            logger: logger
        };
    }
;
module.exports = sideActions;

