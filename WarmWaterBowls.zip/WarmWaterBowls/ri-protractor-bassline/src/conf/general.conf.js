
exports.config = {

    seleniumAddress: 'http://127.0.0.1:4444/wd/hub',
    getPageTimeout: 600001,
    allScriptsTimeout: 5000001,
    framework: 'custom',
    // path relative to the current config file
    frameworkPath: require.resolve('protractor-cucumber-framework'),
    capabilities: {
        'browserName': 'chrome',
    },


    // Spec patterns are relative to this directory.
    specs: [
        'default.feature'
    ],

    ignoreUncaughtExceptions: true,

    baseUrl: 'http://default.base.url',

    pageElementsPath : 'defaultPageElementspath',

    cucumberOpts: {
        require: ['defaultSteps.js'],
        tags: '@defaultTag',
        format: 'pretty',
        profile: false,
        'no-source': true
    },
    onPrepare: function () {
        global.chai = require('chai');
        var chaiAsPromised = require('chai-as-promised');
        chai.use(chaiAsPromised);
        global.expect = chai.expect;
    }
};
