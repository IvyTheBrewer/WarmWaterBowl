module.exports = function() {
    this.setDefaultTimeout(600 * 1000);
};