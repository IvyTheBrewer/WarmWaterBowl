**README.md Placeholder**

This README.md placeholder will contain the manual and other readme data once this package has matured somewhat, until then it's just a placeholder.

`; )`

please add the following dependencies to your project


`"chai": "^3.5.0",
"chai-as-promised": "^6.0.0",
"path": "^0.12.7",
"protractor": "^5.1.1"`