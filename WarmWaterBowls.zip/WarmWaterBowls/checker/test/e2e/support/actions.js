/* global browser, driver, by */

var actions = function () {
        'use strict';


        var clickclick= function(elem){
            return element(by.css(elem)).click();
    }

        return {
            clickclick: clickclick
        };
    }
;
module.exports = actions;
