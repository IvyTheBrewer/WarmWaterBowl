/**
 * Created by StofkoperC on 23-5-2017.
 */

var bedrijven = function(){

  var selectors = {
    body:'body',
    url: 'bedrijven',
    verzekeren : '[data-col="6"][data-row="3"] a'
  };

  return {
    selectors:selectors    }
};


module.exports= bedrijven;


