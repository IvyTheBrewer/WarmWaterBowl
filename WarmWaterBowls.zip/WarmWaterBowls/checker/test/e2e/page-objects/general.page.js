/**
 * Created by StofkoperC on 20-6-2017.
 */
/**
 * Created by StofkoperC on 12-6-2017.
 */

var general = function () {

    var selectors = {
        defaultUser: getDefaultUser(),
        jSonEmptyUserPreferences: '{"personalContentUserPreferences":[{"key":"Biologische_landbouw","value":false},{"key":"Fosfaat","value":false},{"key":"Innovatie","value":false},{"key":"Bedrijf_overdragen","value":false},{"key":"Bedrijf_verkopen","value":false},{"key":"Bedrijf_uitbreiden","value":false},{"key":"Bedrijfsbeeindiging","value":false},{"key":"Technologie","value":false},{"key":"Zuivelprijs","value":false},{"key":"Economische_ontwikkelingen","value":false},{"key":"Stoppersregeling","value":false},{"key":"Onderneming_starten","value":false},{"key":"Eerste_medewerker","value":false},{"key":"Eerste_financiering","value":false},{"key":"Groei_en_investeren","value":false},{"key":"Verduurzamen","value":false},{"key":"Online_afzet_vergroten","value":false},{"key":"Importeren_exporteren","value":false}]}',
        someUserPreferences: '{"personalContentUserPreferences":[{"key":"Biologische_landbouw","value":true},{"key":"Fosfaat","value":true},{"key":"Innovatie","value":false},{"key":"Bedrijf_overdragen","value":false},{"key":"Bedrijf_verkopen","value":true},{"key":"Bedrijf_uitbreiden","value":true},{"key":"Bedrijfsbeeindiging","value":false},{"key":"Technologie","value":false},{"key":"Zuivelprijs","value":false},{"key":"Economische_ontwikkelingen","value":false},{"key":"Stoppersregeling","value":false},{"key":"Onderneming_starten","value":false},{"key":"Eerste_medewerker","value":false},{"key":"Eerste_financiering","value":false},{"key":"Groei_en_investeren","value":false},{"key":"Verduurzamen","value":false},{"key":"Online_afzet_vergroten","value":false},{"key":"Importeren_exporteren","value":false}]}',
        soapBodyGetQuote: '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:ns="http://www.rabobank.nl/XMLHeader/10" xmlns:req="http://www.rabobank.nl/CRM/CRMI/GetQuote/2/Req"><soapenv:Header><ns:RaboHeader><ns:HeaderVersion>10</ns:HeaderVersion><ns:MessageId>1234567890</ns:MessageId><ns:ServiceRequestorDomain>AdviesBedrijven</ns:ServiceRequestorDomain><ns:ServiceRequestorId>MUI-RSGO-LB</ns:ServiceRequestorId><ns:ServiceProviderDomain>CRM</ns:ServiceProviderDomain><ns:ServiceId>GetQuote</ns:ServiceId><ns:ServiceVersion>2</ns:ServiceVersion><ns:FaultIndication>False</ns:FaultIndication><ns:MessageTimestamp>2015-06-8T09:39:29.126Z</ns:MessageTimestamp></ns:RaboHeader></soapenv:Header><soapenv:Body><req:GetQuote_Req><req:Quote><req:QuoteId>1-FA5138</req:QuoteId><req:UnitOfWorkId>1-FA5136</req:UnitOfWorkId></req:Quote></req:GetQuote_Req></soapenv:Body></soapenv:Envelope>',
        postUserPreferencesUrl: getUserPrefPostUrl(),
        getUserPreferencesUrl: getUserPrefGetUrl()
    };


    function getUserPrefPostUrl() {
        return browser.baseUrl.indexOf('localhost') === -1 ? browser.baseUrl + 'diensten/boodschap/personalcontent/postuserpreferences/' : browser.baseUrl + 'diensten/personalcontent/postuserpreferences/';

    }

    function getUserPrefGetUrl() {
        return browser.baseUrl.indexOf('localhost') === -1 ? browser.baseUrl + 'diensten/boodschap/personalcontent/getuserpreferences/' : browser.baseUrl + 'diensten/personalcontent/getuserpreferences/';

    }


    function getDefaultUser() {
        switch (browser.baseUrl) {
            case 'http://localhost/': {
                return '135200000000';
                break;
            }
            case 'http://bankieren-team-110.portaal.rabobank.nl/': {
                return '110800000000';
                break;
            }
        }
    }

    return {
        selectors: selectors
    }
};

module.exports = general;
