/**
 * Created by StofkoperC on 2-6-2017.
 */

var verzekeren = function(){

    var selectors = {
        contentHeader : '[data-col="1"][data-row="1"] .content',
        res: '#center_col #res',
        go: 'button[value="Zoeken"]',
        searchBar : '#lst-ib'
    };

    return {
        selectors:selectors    }
};

module.exports= verzekeren;


