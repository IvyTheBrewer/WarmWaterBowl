/**
 * Created by StofkoperC on 20-6-2017.
 */
/**
 * Created by StofkoperC on 12-6-2017.
 */

var sam = function () {

    var selectors = {
        developmentLogin: '#development-login',
        customerDropdown: '#customerKey',
        login: '#login',
        logout: '#logout',
        defaultUser: getDefaultUser(),
        jimi: getJimi()
    };

    function getDefaultUser() {
        switch (browser.baseUrl) {
            case 'http://localhost/': {
                return '135200000000';
                break;
            }
            case 'http://bankieren-team-110.portaal.rabobank.nl/': {
                return '110800000000';
                break;
            }
        }
    }

    function getJimi() {
        switch (browser.baseUrl) {
            case 'http://localhost/': {
                return '1234567 is not a real number is it?';
                break;
            }
            case 'http://bankieren-team-110.portaal.rabobank.nl/': {
                return '110808000000';
                break;
            }
        }
    }

    return {
        selectors: selectors
    }
};

module.exports = sam;
