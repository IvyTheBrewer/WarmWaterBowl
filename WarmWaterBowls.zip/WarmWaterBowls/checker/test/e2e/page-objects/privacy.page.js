var privacy = function () {

    var selectors = {
        body: 'body',
        url: {
            secure: getSecureUrl(),
            anonymous: getAnonymousUrl()
        },
        confirm: 'button.primary-button',
        level1: '[class*="col-primary"] input[value="1"]',
        level2: '[class*="col-primary"] input[value="2"]',
        level3: '[class*="col-primary"] input[value="3"]'
    };

    function getAnonymousUrl() {
        if (browser.baseUrl.indexOf('acpt')!==-1) return 'https://wwwacceptatie.rabobank.nl/particulieren/privacy/';
        else return 'https://www.kameel.nl';
    }

    function getSecureUrl() {
        if (browser.baseUrl.indexOf('acpt')!==-1) return ((browser.baseUrl.indexOf('acpt3')>-1 ? 'https://bankieren-acpt3' : 'https://bankieren-acpt5'))+
            '.rabobank.nl/klanten/particulieren/privacy'
            ///'https://wwwacceptatie.rabobank.nl/particulieren/privacy/';
        else return 'https://www.kameel.nl';
    }

    return {
        selectors: selectors
    }
};

module.exports = privacy;
