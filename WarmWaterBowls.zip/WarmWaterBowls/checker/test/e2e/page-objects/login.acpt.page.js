/**
 * Created by StofkoperC on 20-6-2017.
 */
/**
 * Created by StofkoperC on 12-6-2017.
 */

var loginAcpt = function () {

    var selectors = {
        part :getPart(),
        zak: getZak(),
        defaultUser: getDefaultUser(),
        accountInput: '#rass-data-reknr',
        loginCode: '#rass-data-inlogcode',
        loginButton: 'input#rass-action-login',
        gencodeAccountInput: 'input#accountNumber',
        gencodeCardInput: 'input#cardNumber',
        gencodeSend: '#gencode-auth button',
        gencodeResult: '#result-panel strong:nth-of-type(2)'
    };


    function getDefaultUser() {
        if (browser.baseUrl.indexOf('acpt3') !== -1) {
            return ['109411188', '3549'];

        }
        else if (browser.baseUrl.indexOf('acpt5') !== -1) {
            return ['126423504', '8090'];
        }

    }

    function getPart() {
        if (browser.baseUrl.indexOf('acpt3') !== -1) {
            return ['109403215', '1109'];

        }
        else if (browser.baseUrl.indexOf('acpt5') !== -1) {
            return ['109619285', '5564'];
        }
    }

    function getZak () {
        if (browser.baseUrl.indexOf('acpt3') !== -1) {
            return ['104566183', '7569'];

        }
        else if (browser.baseUrl.indexOf('acpt5') !== -1) {
            return ['109619285', '5564'];
        }
    }

    return {
        selectors: selectors
    }
};

module.exports = loginAcpt;
