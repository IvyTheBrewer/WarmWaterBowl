/**
 * Created by StofkoperC on 23-5-2017.
 */


var bedrijvenPO = require('./bedrijven.page');
var verzekerenPO = require('./verzekeren.page');
var samPO = require('./sam.page');
var generalPO = require('./general.page');
var loginAcptPO = require('./login.acpt.page');
var privacyPO = require('./privacy.page');

var pageElements = function () {

    var selectPage = {
        bedrijven: bedrijvenPO(),
        verzekeren: verzekerenPO(),
        sam: samPO(),
        general: generalPO(),
        loginAcpt: loginAcptPO(),
        privacy: privacyPO()
    };

    return {
        selectPage: selectPage
    }
};

module.exports = pageElements;




