package utlis;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.cookie.Cookie;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.util.EntityUtils;
import org.junit.Assert;

import java.io.IOException;
import java.util.List;

import static org.hamcrest.CoreMatchers.is;
import static testData.TestData.getTestContext;
import static testData.TestData.urlMap;
import static utlis.Helper.saveCallResults;

/**
 * Created by PanhuisI on 21-3-2018.
 **/
public class Actions {

    public static void authenticateClient(String url, CloseableHttpClient httpclient) {
        try {
            HttpGet httpget = new HttpGet("http://bankieren-team-118.portaal.rabobank.nl/sam/handleLogin.htm?type=customer&securityLevel=3&customerKey=110800000000&siteContextPath=/klanten&url=/bedrijven/verzekeringen/interpolis-zekervanjezaak");
            CloseableHttpResponse response = httpclient.execute(httpget);
            int status = response.getStatusLine().getStatusCode();
            if (status < 200 || status >= 300) {
                throw new ClientProtocolException("Unexpected response status: " + status);
            }
        } catch (IOException e) {
            e.printStackTrace();
            Assert.fail("authentication failed");
        }
    }

//    public static void authenticateClient(String url, CloseableHttpClient httpclient) {
//        try {
//            HttpGet httpget = new HttpGet(url);
//            CloseableHttpResponse response = httpclient.execute(httpget, "sam/handleLogin.htm?type=customer&securityLevel=3&customerKey=110800000000&siteContextPath=/klanten&url=/bedrijven/verzekeringen/interpolis-zekervanjezaak");
//            int status = response.getStatusLine().getStatusCode();
//            if (status < 200 || status >=300) {
//                throw new ClientProtocolException("Unexpected response status: " + status);
//            }
//        } catch (IOException e) {
//            e.printStackTrace();
//            Assert.fail("authentication failed");
//        }
//    }

    public static void getRequest(String url, CloseableHttpClient httpclient) {
        try {
            HttpGet httpGet = new HttpGet(url);
            System.out.println("Executing request " + httpGet.getRequestLine());
            saveCallResults(httpclient.execute(httpGet, getTestContext().localContext));
        } catch (IOException e) {
            e.printStackTrace();
            Assert.fail("Failure while sending get request");
        }
    }

    public static void postRequest(String url, CloseableHttpClient httpclient) {
        try {
            HttpPost httpPost = new HttpPost(urlMap.get(url));
            System.out.println("Executing request " + httpPost.getRequestLine());
            saveCallResults(httpclient.execute(httpPost, getTestContext().localContext));
        } catch (IOException e) {
            e.printStackTrace();
            Assert.fail("Failure while sending post request");
        }
    }

    public static void postRequest(String url, CloseableHttpClient httpclient, String jsonFile) {
        try {
            jsonFile = getTestContext().loadJsonFromFile(jsonFile);
            StringEntity payload = new StringEntity(jsonFile, ContentType.APPLICATION_JSON);
            HttpPost httpPost = new HttpPost(urlMap.get(url));
            httpPost.setEntity(payload);
            System.out.println("Executing request " + httpPost.getRequestLine());
            saveCallResults(httpclient.execute(httpPost, getTestContext().localContext));
        } catch (IOException e) {
            e.printStackTrace();
            Assert.fail("Failure while sending post request");
        }
    }

    public static String getBody(CloseableHttpResponse response) {
        String body = "";
        try {
            body = EntityUtils.toString(response.getEntity());
        } catch (IOException e) {
            e.printStackTrace();
            Assert.fail("Failed to get the body out of the response");
        }
        return body;
    }

    public static void assertJsonPathResultEquals(String json, String query, String expectedResult) {
        ObjectMapper objectMapper = new ObjectMapper();
        try {
            JsonNode root = objectMapper.readTree(json);
            Assert.assertThat(root.at(query).asText(), is(expectedResult));
        } catch (IOException e) {
            e.printStackTrace();
            Assert.fail("Failed to parse Json response");
        }
    }

    public static void assertResponseContainsCookie(String cookieName, String cookieValue) {
        boolean check = false;
        List<Cookie> cookies = getTestContext().cookieStore.getCookies();
        for (Cookie cookie : cookies){
            if (cookie.getName().equals(cookieName) && cookie.getValue().equals(cookieValue)) check = true;
        }
        Assert.assertTrue("The cookie with name " + cookieName + " and value "+ cookieValue + " was not found. The cookies found were : " + cookies,check);
    }

    public static void assertResponseContainsCookie(String cookieName) {
        boolean check = false;
        List<Cookie> cookies = getTestContext().cookieStore.getCookies();
        for (Cookie cookie : cookies){
            if (cookie.getName().equals(cookieName)) check = true;
        }
        Assert.assertTrue("The cookie with name " + cookieName + " was not found. The cookies found were : " + cookies,check);
    }
}
