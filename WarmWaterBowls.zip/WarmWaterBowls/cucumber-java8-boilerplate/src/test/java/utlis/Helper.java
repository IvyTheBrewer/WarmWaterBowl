package utlis;

import org.apache.http.client.methods.CloseableHttpResponse;

import static testData.TestData.getTestContext;
import static utlis.Actions.getBody;

/**
 * Created by PanhuisI on 21-3-2018.
 **/
public class Helper {
    public static void saveCallResults(CloseableHttpResponse response){
        getTestContext().requestResponse = response;
        getTestContext().requestResponseBody = getBody(response);
    }
}
