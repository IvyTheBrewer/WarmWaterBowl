package steps;

import cucumber.api.PendingException;
import cucumber.api.java8.En;
import org.junit.Assert;

import java.util.Arrays;

import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.CoreMatchers.is;
import static testData.TestData.getTestContext;
import static testData.TestData.urlMap;
import static utlis.Actions.*;

/**
 * Created by PanhuisI on 21-3-2018.
 **/
public class Steps implements En {
    public Steps() {

        // Calling api's///

        Given("^I authenticate the httpClient$", () -> authenticateClient(urlMap.get("loginSam"), getTestContext().httpClient));

        Given("^I send a get call to \"([^\"]*)\"$", (String url)
                -> getRequest(urlMap.get(url), getTestContext().httpClient));

 /*       When("^I send a post call to \"([^\"]*)\"$", (String url) ->  postRequest(url, getTestContext().httpClient));

        When("^I send a post call to \"([^\"]*)\" sending json \"([^\"]*)\"$", (String url, String jsonFile)
                -> postRequest(url, getTestContext().httpClient, jsonFile));
*/
        // Verifiying results //

        Then("^the response has code \"([^\"]*)\"$", (String code) -> {
            int actual = getTestContext().requestResponse.getStatusLine().getStatusCode();
            Assert.assertThat(actual, is(Integer.parseInt(code)));
        });

        And("^the query \"([^\"]*)\" on the response returns \"([^\"]*)\"$", (String query, String expectedResult)
                -> assertJsonPathResultEquals(getTestContext().requestResponseBody,query, expectedResult));

        And("^the response cookies contain a cookie with name \"([^\"]*)\" and value \"([^\"]*)\"$", (String cookieName, String cookieValue) -> assertResponseContainsCookie(cookieName, cookieValue));

        And("^the response cookies contain a cookie with name \"([^\"]*)\"$", (String cookieName) -> assertResponseContainsCookie(cookieName));

    }

}
