package steps;

import cucumber.api.java.After;
import cucumber.api.java.Before;

import java.io.IOException;

import static testData.TestData.*;

/**
 * Created by PanhuisI on 21-3-2018.
 **/
public class Hooks {
    @Before
    public void beforeScenario() {
    }

    @After
    public void afterScenario() {
        try {
            getTestContext().httpClient.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        finally {
            closeTestContext();
        }
    }
}
