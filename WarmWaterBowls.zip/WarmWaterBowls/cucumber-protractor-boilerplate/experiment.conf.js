/**
 * Created by panhuisi on 6-10-2017.
 */

'use strict';

const path = require('path');
const projectRoot = process.cwd();
const remote = path.join(projectRoot, 'node_modules/ri-protractor-bassline/src');
const remoteStepsPath = path.join(remote, 'js');
global.config = require(path.join(remote, 'conf/general.conf')).config;

config.cucumberOpts = {
    require: [
        path.join(remote, 'conf/env.js'),
        path.join(remoteStepsPath, '*.js'),
        path.join(projectRoot, 'test/e2e/steps/*.js')
    ],
    tags:
    '@check,' +
    '@acc,' +
    '@team,' +
    '@checkApitt,' +
    '@checkApi,',
    format: 'pretty',
    profile: false,
    'no-source': true
};

config.baseUrl = 'http://wwwacceptatie.rabobank.nl/';

config.specs = 'test/e2e/features/e2e.feature';

config.pageElementsPath = path.join(projectRoot, 'test/e2e/page-objects/pageElements.js');

exports.config = config;


