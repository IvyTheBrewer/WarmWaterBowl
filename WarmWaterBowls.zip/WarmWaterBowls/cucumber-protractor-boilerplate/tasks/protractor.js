/**
 * Created by StofkoperC on 23-5-2017.
 */
var path = require('path'),
//protractorUtils = require('../node_modules/senses-frontend-tools/node_modules/protractor-utils'),
  protractorUtils = require('protractor-utils'),
  localConfig = require(path.resolve(__dirname, '../e2e.conf')).settings;

module.exports = extendProtractorTasks();

function extendProtractorTasks() {

  var tasks = {
    // Default options
    options: {
      configFile: localConfig.config.local,
      keepAlive: false, // If a test fails the grunt process needs to be killed to set the right build status in jenkins
      noColor: false, // If true, protractor will not use colors in its output.
      debug: false,
      args: {
        baseUrl: localConfig.urls.baseUrl.teamServer,
        specs: [
          path.resolve(localConfig.e2eRoot, 'basic.integration.flow.feature')
        ],
        cucumberOpts: {
          tags: '@smoke',
          require: [
            // also accommodate for generic.steps.js in the e2e root directory
            path.resolve(localConfig.toolRoot, '**/hooks/**/*.js'),
            path.resolve(localConfig.e2eRoot, '**/*.steps.js'),
            path.resolve(localConfig.e2eRoot, '**/*.hooks.js'),
            path.resolve(localConfig.e2eRoot, '**/*.page.js')
          ]
        }

      }
    },

    // All default local tasks //
    // Run tests local
    main: {},

    // Run tests local on a phone emulated by chrome
    chromeEmulator: {
      options: {
        configFile: localConfig.config.chromeEmulator
      }
    },

    // Run tests local on a physical device
    realDevice: {
      options: {
        configFile: localConfig.config.realDevice
      }
    },


    // All external tasks //
    // Run a smoketest on the browserlab
    browserLabSmoke: {
      options: {
        configFile: localConfig.config.browserLabSmoke,
        args: {
          cucumberOpts: {
            tags: '@smoke'
          }
        }
      }
    },

    // Run tests on all browsers in scope in the browserlab
    browserLabBrowsers: {
      options: {
        configFile: localConfig.config.browserLabBrowsers
      }
    },

    // Run tests on Perfecto devices in the app
    perfectoApp: {
      options: {
        configFile: localConfig.config.perfectoApp,
        args: {
          cucumberOpts: {
            tags: '~@nonPerfecto'
          }
        }
      }
    },

    // Run tests on Perfecto devices in the browsers
    perfectoBrowsers: {
      options: {
        configFile: localConfig.config.perfectoBrowsers,
        args: {
          cucumberOpts: {
            tags: '~@nonPerfecto'
          }
        }
      }
    },

    // Run tests on Perfecto devices in public-cloud
    perfectoPublic: {
      options: {
        configFile: localConfig.config.perfectoPublic,
        args: {
          baseUrl: localConfig.urls.baseUrl.chain,
          cucumberOpts: {
            tags: '~@nonPerfecto'
          }
        }
      }
    },

    customerViewLocalBrowser: {
      options: {
        configFile: localConfig.config.personalContent,
        args: {
          specs: [
            path.resolve(localConfig.e2eRoot, 'customer.view.feature')
          ],
          cucumberOpts: {
            tags: '@smoke'
          }

        }
      }
    },

    customerViewPerfectoBrowsers: {
      options: {
        configFile: localConfig.config.perfectoBrowsers,
        args: {
          specs: [
            path.resolve(localConfig.e2eRoot, 'customer.view.feature')
          ],
          cucumberOpts: {
            tags: '@teamServer'
          }

        }
      }
    },

    checkSecure: {
      options: {
        configFile: localConfig.config.personalContent,
        args: {
          specs: [
            path.resolve(localConfig.e2eRoot, 'features/given.feature')
          ],
          cucumberOpts: {
            tags: '@checkSecure',
            require: [
              // also accommodate for generic.steps.js in the e2e root directory
              path.resolve(localConfig.toolRoot, '**/hooks/**/*.js'),
              path.resolve(localConfig.e2eRoot, '**/steps.js'),
              path.resolve(localConfig.e2eRoot, '**/*.hooks.js'),
              path.resolve(localConfig.e2eRoot, '**/*.page.js')
            ]
          }
        }
      }
    },

    checkAnoniem: {
      options: {
        configFile: localConfig.config.personalContent,
        args: {
          baseUrl: localConfig.urls.baseUrl.teamServerAnoniem,
          specs: [
            path.resolve(localConfig.e2eRoot, 'features/basicFeatures.feature')
          ],
          cucumberOpts: {
            tags: '@checkAnoniem',
            require: [
              // also accommodate for generic.steps.js in the e2e root directory
              path.resolve(localConfig.toolRoot, '**/hooks/**/*.js'),
              path.resolve(localConfig.e2eRoot, '**/steps.js'),
              path.resolve(localConfig.e2eRoot, '**/*.hooks.js'),
              path.resolve(localConfig.e2eRoot, '**/*.page.js')
            ]
          }
        }
      }
    },

    AccAnoniem: {
      options: {
        configFile: localConfig.config.personalContent,
        args: {
          baseUrl: localConfig.urls.baseUrl.accServerAnoniem,
          specs: [
            //path.resolve(localConfig.e2eRoot, 'features/given.feature'),
            path.resolve(localConfig.e2eRoot, 'features/basicFeatures.feature')
          ],
          cucumberOpts: {
            tags: '@AccAnoniem',
            require: [
              // also accommodate for generic.steps.js in the e2e root directory
              path.resolve(localConfig.toolRoot, '**/hooks/**/*.js'),
              path.resolve(localConfig.e2eRoot, '**/steps.js'),
              path.resolve(localConfig.e2eRoot, '**/when.js'),
              path.resolve(localConfig.e2eRoot, '**/*.hooks.js'),
              path.resolve(localConfig.e2eRoot, '**/*.page.js')
            ]
          }
        }
      }
    },

    local: {
      options: {
        configFile: localConfig.config.personalContent,
        args: {
          baseUrl: localConfig.urls.baseUrl.develop,
          specs: [
            path.resolve(localConfig.e2eRoot, 'features/e2e.feature')
          ],
          cucumberOpts: {
            tags: '@thisTagIsSpecifiedInprotractorJsInFolderTasks',
            require: [
              // also accommodate for generic.steps.js in the e2e root directory
              path.resolve(localConfig.toolRoot, '**/hooks/**/*.js'),
              path.resolve(localConfig.e2eRoot, '**/steps.js'),
              path.resolve(localConfig.e2eRoot, '**/when.js'),
              path.resolve(localConfig.e2eRoot, '**/*.hooks.js'),
              path.resolve(localConfig.e2eRoot, '**/*.page.js')
            ]
          }

        }
      }
    },

    // Run tests on Perfecto Device(s) based on a command line filter, if no filter is provided the default will be taken
    perfectoCapabilityFilter: {
      options: {
        configFile: localConfig.config.perfectoCapabilityFilter,
        args: {
            specs: [
                path.resolve(localConfig.e2eRoot, 'features/e2e.feature')
            ],
          cucumberOpts: {
            // tags: '', //'~@nonPerfecto', '~@wip',
            tags: '@thisTagIsSpecifiedInprotractorJsInFolderTasks', //'~@nonPerfecto', '~@wip',
            require: [
                // also accommodate for generic.steps.js in the e2e root directory
                path.resolve(localConfig.toolRoot, '**/hooks/**/*.js'),
                path.resolve(localConfig.e2eRoot, '**/steps.js'),
                path.resolve(localConfig.e2eRoot, '**/when.js'),
                path.resolve(localConfig.e2eRoot, '**/*.hooks.js'),
                path.resolve(localConfig.e2eRoot, '**/*.page.js')
            ]
          }
        }
      }
    },

    // Run tests on Perfecto Browsers (Chrome / Firefox / Internet Explorer)
    perfectoDesktop: {
      options: {
        configFile: localConfig.config.perfectoDesktop,
        args: {
          baseUrl: localConfig.urls.baseUrl.teamServer,
          specs: [
            path.resolve(localConfig.e2eRoot, 'features/e2e.feature')
          ],
          cucumberOpts: {
            //tags: '@thisTagIsSpecifiedInprotractorJsInFolderTasks',
            require: [
              // also accommodate for generic.steps.js in the e2e root directory
              path.resolve(localConfig.toolRoot, '**/hooks/**/*.js'),
              path.resolve(localConfig.e2eRoot, '**/steps.js'),
              path.resolve(localConfig.e2eRoot, '**/when.js'),
              path.resolve(localConfig.e2eRoot, '**/*.hooks.js'),
              path.resolve(localConfig.e2eRoot, '**/*.page.js')
            ]
          }
        // args: {
        //   cucumberOpts: {
        //     //tags: ['~@nonPerfecto', '~@wip', '~@nonDesk'],
        //     tags: ['perfectoM'],
        //     require: [
        //       path.resolve(localConfig.e2eRoot, '**/*.hooks.js')
        //     ]
        //   }
        }
      }
    },


    teamServer: {
      options: {
        configFile: localConfig.config.thisProject,
        args: {
          baseUrl: localConfig.urls.baseUrl.teamServer,
          specs: [
            path.resolve(localConfig.e2eRoot, 'features/e2e.feature')
          ],
          cucumberOpts: {
            tags: '@thisTagIsSpecifiedInprotractorJsInFolderTasks',
            require: [
              // also accommodate for generic.steps.js in the e2e root directory
              path.resolve(localConfig.toolRoot, '**/hooks/**/*.js'),
              path.resolve(localConfig.e2eRoot, '**/steps.js'),
              path.resolve(localConfig.e2eRoot, '**/when.js'),
              path.resolve(localConfig.e2eRoot, '**/*.hooks.js'),
              path.resolve(localConfig.e2eRoot, '**/*.page.js')
            ]
          }

        }
      }
    },

    browserlab: {
      options: {
        configFile: localConfig.config.browserLabBrowsers,
        args: {
          specs: [
            path.resolve(localConfig.e2eRoot, 'features/e2e.feature')
          ],
          cucumberOpts: {
            tags: '@browserlab',
            require: [
              // also accommodate for generic.steps.js in the e2e root directory
              path.resolve(localConfig.e2eRoot, '**/steps.js'),
              path.resolve(localConfig.e2eRoot, '**/when.js'),
              path.resolve(localConfig.e2eRoot, '**/*.hooks.js'),
              path.resolve(localConfig.e2eRoot, '**/*.page.js')
            ]
          }

        }
      }
    },

    devices: {
      options: {
        configFile: localConfig.config.perfectoApp,
        args: {
          specs: [
            path.resolve(localConfig.e2eRoot, 'showCustomerViewDetails.feature')
          ],
          cucumberOpts: {
            tags: '@smoke,@device',
            require: [
              // also accommodate for generic.steps.js in the e2e root directory
              path.resolve(localConfig.toolRoot, '**/hooks/**/*.js'),
              path.resolve(localConfig.e2eRoot, '**/showCustomerViewDetails.steps.js'),
              path.resolve(localConfig.e2eRoot, '**/*.hooks.js'),
              path.resolve(localConfig.e2eRoot, '**/*.page.js')
            ]
          }

        }
      }
    }

  };

  return protractorUtils.utils.extendTasks(tasks);
}
