/* global browser, driver, by */

var pageElements = require(config.pageElementsPath);

var actions = function () {
        'use strict';


        var clickclick = function (elem) {
            return element(by.css(elem)).click();
        };

        var compareArrays = function (a, b, page) {
            return new Promise(function (resolve, reject) {
                var frontendValues = pageElements().selectPage[page].selectors[a];
                var stubValues = pageElements().selectPage[page].selectors[b];
                var expectedLength = stubValues.length;
                for (var i = 0; i < expectedLength; i++) {
                    if (frontendValues.length < i + 1) {
                        console.log('There are ' + (expectedLength - i) + ' expected values missing, expected ' + expectedLength + ' but only found ' + i);
                        i = expectedLength; // shortcut to end for loop
                        reject();
                    } else if (frontendValues.length >= i + 1) {
                        if (frontendValues[i].x === stubValues[i].x) {
                            if (frontendValues[i].y === stubValues[i].y) {
                                console.log('The actual value of ' + frontendValues[i].x + 'was ' + frontendValues[i].y + ', just as we expected!' + ' ' + (i + 1));
                            } else {
                                console.log('The actual value of "y" was: ' + frontendValues[i].y + ' but we expected is to be: ' + stubValues[i].y + ' ' + (i + 1));
                                reject();
                            }
                        } else {
                            console.log('The actual value of "x" was: ' + frontendValues[i].x + ' but we expected is to be: ' + stubValues[i].x + ' ' + (i + 1));
                            reject();
                        }
                    } else {
                        console.log('An uncaught error occurred, please check code!');
                        reject();
                    }
                }
                resolve();
            })
        };

    var extractStubData = function (url) {
        browser.driver.manage().window().setSize(0, 0);
        return new Promise(function (resolve, reject) {
            browser.stubArray = [];
            request.get(url).end(function (err, response) {
                if (err) {
                    console.log('An error has been thrown:' + ' - error code: ', err.code + ' - error status: ', err.status);
                    reject(err);
                } else if (response) {
                    browser.stubArray = response.body.datapoints;
                    resolve();
                } else {
                    console.log('An uncaught error occurred, please check code!');
                    reject(err);
                }
            });
            return browser.stubArray;
        })
    };

    /**
     *
     * @param callback
     */
    var getMouseOverValues = function (callback) {
        browser.manage().window().maximize();
        browser.elementCenterPosition = null;
        browser.mouseOverArray = [];
        var arrayLength = browser.classArray.length;

        function looper(counter) {
            helper().getElementCenterPosition(browser.classArray[counter])
                .then(function (centerPosition) {
                    browser.elementCenterPosition = centerPosition;
                    browser.actions().mouseMove(browser.classArray[counter], {
                        x: browser.elementCenterPosition,
                        y: -50
                    }).click().perform();
                })
                .then(function () {
                    browser.classArray[counter].getText()
                        .then(function (legend) {
                            browser.mouseOverArray.push({"x": legend, "y": 0});
                            element(by.css('.focus text')).getText()
                                .then(function (onScreenNumber) {
                                    browser.mouseOverArray[counter].y = onScreenNumber;
                                });
                        });
                });
        }

        for (var i = 0; i < arrayLength; i++) {
            looper(i);
        }
        browser.sleep(1)
            .then(callback);
    };

        return {
            clickclick: clickclick,
            compareArrays: compareArrays,
            extractStubData: extractStubData,
            getMouseOverValues: getMouseOverValues
        };
    }
;
module.exports = actions;
