
var actions = require('../support/actions');

/*jshint validthis:true */
function given () {
    'use strict';
    this.Given(/^I clickclick the "([^"]*)"$/, actions().clickclick);
}
module.exports = given;