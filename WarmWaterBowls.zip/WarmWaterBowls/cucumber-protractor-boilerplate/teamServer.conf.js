exports.config = {
    seleniumAddress: 'http://127.0.0.1:4444/wd/hub',
    getPageTimeout: 600001,
    allScriptsTimeout: 5000001,
    framework: 'custom',
    // path relative to the current config file
    frameworkPath: require.resolve('protractor-cucumber-framework'),
    capabilities: {
        'browserName': 'chrome',
    },


    // Spec patterns are relative to this directory.
    specs: [
        'test/e2e/features/e2e.feature'
    ],

    ignoreUncaughtExceptions: true,

    baseUrl: 'http://bankieren-team-110.portaal.rabobank.nl/',
    //baseUrl: 'https://bankieren-acpt5.rabobank.nl/',

    cucumberOpts: {
        require: ['test/e2e/features/step_definitions/*.js',
        'test/e2e/conf/env.js'],
        tags: '@thisTagIsSpecifiedInprotractorJsInFolderTasks----,@team---, @checkApi',
        format: 'pretty',
        profile: false,
        'no-source': true
    },
    onPrepare: function () {
        global.chai = require('chai');
        var chaiAsPromised = require('chai-as-promised')
        chai.use(chaiAsPromised);
        global.expect = chai.expect;
    }
};