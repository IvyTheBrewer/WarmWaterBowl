package utils;

import org.apache.http.client.methods.CloseableHttpResponse;

import static testData.TestData.getTestContext;
import static utils.Actions.getBody;

/**
 * Created by StofkoperC on 24-8-2017.
 */
public class Helper {
    public static void saveCallResults(CloseableHttpResponse response){
        getTestContext().requestResponse = response;
        getTestContext().requestResponseBody = getBody(response);
    }
}
