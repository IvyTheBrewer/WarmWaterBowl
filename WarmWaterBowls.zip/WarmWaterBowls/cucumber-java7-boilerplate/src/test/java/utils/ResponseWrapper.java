package utils;

import java.util.List;

/**
 * Created by panhuisi on 31-8-2017.
 */
public class ResponseWrapper {

    private List<Datapoint> balance;
    private List<Datapoint> creditlimit;
    private List<Datapoint> revenue;
    private List<Datapoint> expenses;
    private List<Datapoint> savings;

    public List<Datapoint> getBalance() {
        return balance;
    }

    public void setBalance(List<Datapoint> balance) {
        this.balance = balance;
    }

    public List<Datapoint> getCreditlimit() {
        return creditlimit;
    }

    public void setCreditlimit(List<Datapoint> creditlimit) {
        this.creditlimit = creditlimit;
    }

    public List<Datapoint> getRevenue() {
        return revenue;
    }

    public void setRevenue(List<Datapoint> revenue) {
        this.revenue = revenue;
    }

    public List<Datapoint> getExpenses() {
        return expenses;
    }

    public void setExpenses(List<Datapoint> expenses) {
        this.expenses = expenses;
    }

    public List<Datapoint> getSavings() {
        return savings;
    }

    public void setSavings(List<Datapoint> savings) {
        this.savings = savings;
    }

    @Override
    public String toString() {
        return "ResponseWrapper{" +
                "balance=" + balance +
                ", creditlimit=" + creditlimit +
                ", revenue=" + revenue +
                ", expenses=" + expenses +
                ", savings=" + savings +
                '}';
    }
}
