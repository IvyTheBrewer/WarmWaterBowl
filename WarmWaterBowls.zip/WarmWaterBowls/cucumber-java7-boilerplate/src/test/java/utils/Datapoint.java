package utils;

/**
 * Created by panhuisi on 31-8-2017.
 */
public class Datapoint {

    String date;
    int value;

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public int getValue() {
        return value;
    }

    public void setValue(int value) {
        this.value = value;
    }

    @Override
    public String toString() {
        return "Datapoint{" +
                "date='" + date + '\'' +
                ", value=" + value +
                '}';
    }
}
