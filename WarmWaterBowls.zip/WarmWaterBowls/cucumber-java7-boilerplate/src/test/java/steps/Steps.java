package steps;

import cucumber.api.PendingException;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.junit.Assert;
import utils.Actions;

import static org.hamcrest.core.Is.is;
import static testData.TestData.getTestContext;
import static testData.TestData.urlMap;


/**
 * Created by panhuisi on 29-8-2017.
 */
public class Steps {
    @Given("^I authenticate the httpClient$")
    public void iAuthenticateTheHttpClient() throws Throwable {
        Actions.authenticateClient(urlMap.get("loginSam"), getTestContext().httpClient);
    }

//    @When("^I send a get call to \"([^\"]*)\"$")
//    public void iSendAGetCallTo(String url) throws Throwable {
//        Actions.postRequest(url, getTestContext().httpClient);
//    }

    @When("^I send a get call to \"([^\"]*)\"$")
    public void iSendAGetCallTo(String url) throws Throwable {
        Actions.getRequest(url, getTestContext().httpClient);
    }

    @When("^I send a get call to \"([^\"]*)\" with the header key \"([^\"]*)\" and header value \"([^\"]*)\"$")
    public void iSendAGetCallTo(String url, String headerKey, String headerValue) throws Throwable {
        Actions.getRequest(url, getTestContext().httpClient, headerKey, headerValue);
    }

    @Then("^the response has code \"([^\"]*)\"$")
    public void theResponseHasCode(String code) throws Throwable {
        int actual = getTestContext().requestResponse.getStatusLine().getStatusCode();
        Assert.assertThat(actual, is(Integer.parseInt(code)));
    }

    @When("^I send a post call to \"([^\"]*)\" sending json \"([^\"]*)\"$")
    public void iSendAPostCallToSendingJson(String url, String jsonFile) throws Throwable {
        Actions.postRequest(url, getTestContext().httpClient, jsonFile);
    }

    @And("^the query \"([^\"]*)\" on the response returns \"([^\"]*)\"$")
    public void theQueryOnTheResponseReturns(String query, String expectedResult) throws Throwable {
        Actions.assertJsonPathResultEquals(getTestContext().requestResponseBody,query, expectedResult);
    }

    @When("^I send a post call to \"([^\"]*)\"$")
    public void iSendAPostCallTo(String url) throws Throwable {
        Actions.postRequest(urlMap.get(url), getTestContext().httpClient);
    }

//    @When("^I send a post call to \"([^\"]*)\"$")
//    public void iSendAPostCallTo(String url) throws Throwable {
//        Actions.getRequest(urlMap.get(url), getTestContext().httpClient);
//    }

    @And("^the response cookies contain a cookie with name \"([^\"]*)\"$")
    public void theResponseCookiesContainACookieWithName(String cookieName) throws Throwable {
        Actions.assertResponseContainsCookie(cookieName);
    }

    @And("^the response cookies contain a cookie with name \"([^\"]*)\" and value \"([^\"]*)\"$")
    public void theResponseCookiesContainACookieWithNameAndValue(String cookieName, String cookieValue) throws Throwable {
        Actions.assertResponseContainsCookie(cookieName, cookieValue);
    }

    @And("^the response can be split into Hashmaps$")
    public void theResponseCanBeSplitIntoHashmaps() throws Throwable {
        Actions.splitResponseIntoMaps();
    }

    @Then("^I verify that the output of \"([^\"]*)\" equals the output of \"([^\"]*)\"$")
    public void iVerifyThatTheOutputOfEqualsTheOutputOf(String url1, String url2) throws Throwable {
        Actions.compareOutputOfServices(url1, url2);
    }
}
