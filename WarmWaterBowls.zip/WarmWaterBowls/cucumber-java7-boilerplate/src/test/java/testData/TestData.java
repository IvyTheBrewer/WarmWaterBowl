package testData;

import net.sf.json.JSONObject;
import net.sf.json.JSONSerializer;
import org.apache.commons.io.IOUtils;
import org.apache.http.client.CookieStore;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.protocol.ClientContext;
import org.apache.http.client.protocol.HttpClientContext;
import org.apache.http.impl.client.BasicCookieStore;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.protocol.BasicHttpContext;
import org.apache.http.protocol.HttpContext;
import org.junit.Assert;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Properties;

/**
 * Created by StofkoperC on 10-8-2017.
 */
public class TestData {
    private static TestData myself = null;
    public static String baseUrl;
    public static String jsonFilePath;
    public CloseableHttpClient httpClient = HttpClients.createDefault();
    public CloseableHttpResponse requestResponse;
    public String requestResponseBody;
    public CookieStore cookieStore;
    public HttpContext localContext;
    public static HashMap<String, String> urlMap = new HashMap<>();
    public static HashMap<String, String> jsonDataMap = new HashMap<>();

    static {
        readProperties();
//        urlMap.put("getUserPrefs", baseUrl + "diensten/boodschap/personalcontent/getuserpreferences");
//        urlMap.put("postUserPrefs", baseUrl + "diensten/boodschap/personalcontent/postuserpreferences");
        urlMap.put("pifProxy", baseUrl + "diensten/bedrijfskompas/proxy");
        urlMap.put("APIStub", "http://lsrv6498.linux.rabobank.nl:8091/liquidity?customerId=111244109000735");
//        urlMap.put("woosh",  "http://www-team-110.portaal.rabobank.nl/diensten/boodschap/klantervaring/sessioncookie");
//        urlMap.put("cookieLevel3",  "http://www-team-110.portaal.rabobank.nl/diensten/boodschap/klantervaring/optimaal");
        urlMap.put("loginSam", baseUrl + "sam/handleLogin.htm?type=customer&securityLevel=3&customerKey=110800000000&siteContextPath=/klanten&url=/pif-test-portlets");
    }

    private TestData() {
        cookieStore = new BasicCookieStore();
        localContext = new BasicHttpContext();
        localContext.setAttribute(HttpClientContext.COOKIE_STORE, cookieStore);
    }

    private static void readProperties() {
        try {
            Properties properties = new Properties();
            InputStream inputStream = new FileInputStream("./src/test/resources/config.properties");
            properties.load(inputStream);
            baseUrl = properties.getProperty("baseUrl");
            jsonFilePath = System.getProperty("user.dir") + properties.getProperty("jsonFilePath");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static TestData getTestContext() {
        if (myself == null) {
            myself = new TestData();
        }
        return myself;
    }

    public static void closeTestContext() {
        myself = null;
    }

    public String loadJsonFromFile(String file) {
        String jsonTxt="";
        try {
            InputStream is =
                    //TestData.class.getResourceAsStream(jsonFilePath +file);
                    new FileInputStream(jsonFilePath +file);
            jsonTxt = IOUtils.toString(is);
        }catch (IOException e){
            e.printStackTrace();
            Assert.fail("Failed to load file: "+ file);
        }
        return jsonTxt;
    }

}

