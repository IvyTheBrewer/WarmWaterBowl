## Install
clone from git 
mvn clean install

## Running tests

Either right-click src\test\java\steps\TestRunner.java -> Run TestRunner
or in commandline: mvn test

## Basics
There is a config.properties file with basic configuration such as BaseUrl. If needed follow that example and expand.
There is a TestDataClass with static members that will be available during all tests. An instance can be obtained through 
getTestContext() and this context is closed after each scenario in src/test/java/steps/Hooks. This instance contains members such as 
the requestResponse that can be used throughout the scenario.


## Further info

For more info on the library search for apache http client or http://hc.apache.org/httpcomponents-client-ga/httpclient/apidocs/
For more info on querying the response body search for Jackson JsonPointer.

## If you add cool stuff let us know!